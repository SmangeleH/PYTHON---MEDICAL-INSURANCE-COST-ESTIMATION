"""Medical Insurance Cost Estimator

A beginner-friendly Python project that estimates yearly medical insurance costs
using a simple formula and tests how changes in selected variables affect the result.
"""

def estimate_insurance_cost(age: int, sex: int, bmi: float, num_of_children: int, smoker: int) -> float:
    """Return estimated insurance cost based on the provided formula."""
    return (
        250 * age
        - 128 * sex
        + 370 * bmi
        + 425 * num_of_children
        + 24000 * smoker
        - 12500
    )


def main() -> None:
    # Initial profile
    age = 28
    sex = 0  # 0 = female, 1 = male
    bmi = 26.2
    num_of_children = 3
    smoker = 0  # 0 = non-smoker, 1 = smoker

    insurance_cost = estimate_insurance_cost(age, sex, bmi, num_of_children, smoker)
    print(f"Base insurance cost: ${insurance_cost}")

    # Age scenario
    new_age = age + 4
    age_adjusted_cost = estimate_insurance_cost(new_age, sex, bmi, num_of_children, smoker)
    print(f"Change after increasing age by 4 years: ${age_adjusted_cost - insurance_cost}")

    # BMI scenario
    new_bmi = bmi + 3.1
    bmi_adjusted_cost = estimate_insurance_cost(age, sex, new_bmi, num_of_children, smoker)
    print(f"Change after increasing BMI by 3.1: ${bmi_adjusted_cost - insurance_cost}")

    # Sex scenario
    male_cost = estimate_insurance_cost(age, 1, bmi, num_of_children, smoker)
    print(f"Change for being male instead of female: ${male_cost - insurance_cost}")


if __name__ == "__main__":
    main()
